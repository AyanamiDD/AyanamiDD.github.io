# Changelog

## 2020.10.08

1. add Font Selector into app

## 2019.05.04
1. Fix Typo at Slogan.vue
2. Add vuex for keep text while switch layout
3. use Canvas export

## 2019.03.26

1. add Vertical Pornhub Logo

## 2019.03.25

1. Download Image with Dark Background.
2. Inverse prefix and suffix

## 2019.03.23

1. Init Project
2. Download as PNG
3. Custom Font Style
