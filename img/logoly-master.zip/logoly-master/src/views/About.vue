<template>
  <div class="about">
    <h3>Logoly.pro</h3>
    <p>This project is an open source project, you can find it on <a href="https://github.com/bestony/logoly" target="_blank"> GitHub</a></p>
  </div>
</template>
<style lang="stylus" scoped>
p
  color #fff
</style>
