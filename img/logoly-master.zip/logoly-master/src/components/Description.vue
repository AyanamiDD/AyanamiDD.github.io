<style lang="stylus" scoped>
    h2
        color #fff;
</style>

<template>
    <div class="description">
       <h2>A Simple Online Logo Generator</h2>
    </div>
</template>
