<style lang="stylus" scoped>
p 
    color #fff
.prefix 
    color #fff
    padding 5px 0px
.postfix
    color #000
    background-color #f90
    padding 5px 5px
    margin-left 5px
    border-radius 7px
</style>

<template>
    <div class="slogan">
        <h3>
            <span class="prefix">Logoly</span>
            <span class="postfix">Pro</span>
        </h3>
        <p>
            Logoly.pro is a creative logo generator, you can generate logo similar to Pornhub, YouTube, and more.
            <br><br>
            <strong style="color:#f90">
            If you think this project is funny, please 
            <a href="https://github.com/bestony/logoly">
            <img src="https://img.shields.io/badge/give%20me-a%20star-green.svg" />
            </a>
            </strong>
        </p>
    </div>
</template>
