<style lang="stylus" scoped>
p
    text-align center
    color #666
</style>

<template>
    <p>© Bestony 2019 <a href="https://bitbear.net/?refcode=1ndyezv73" target="_blank">比特熊,微服务</a></p>
</template>
