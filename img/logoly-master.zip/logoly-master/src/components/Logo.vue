<style lang="stylus" scoped>
.logo
    padding 50px 0px 20px
.prefix
    color #fff
    padding 5px
.postfix
    color #000
    background-color #f90
    padding 5px
    border-radius 7px
</style>

<template>
  <div class="logo">
    <h1>
      <span class="prefix">Logoly</span>
      <span class="postfix">Pro</span>
    </h1>
  </div>
</template>
